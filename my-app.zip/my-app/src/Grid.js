
import {AgGridColumn, AgGridReact} from 'ag-grid-react';
import React, { useState, useEffect } from 'react';
import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-alpine.css';

import Util from './Util'

const Grid = (props) => {
   
  



  const dynamicCellStyle = params => {
     return Util.getColorCode(params.data.aqi);
     
};

   return (
       <div className="ag-theme-alpine" style={{height: 400, width: 600}}>
           <AgGridReact
               rowData={props.rowData}>
               <AgGridColumn headerName="City" field="city" sortable={ true } filter={ true }></AgGridColumn>
               <AgGridColumn  headerName= "Current AQI" field="aqi" cellStyle={dynamicCellStyle} sortable={ true } filter={ true }></AgGridColumn>
               <AgGridColumn headerName= "Last updated" field="time" sortable={ true } filter={ true }></AgGridColumn>
           </AgGridReact>
       </div>
   );
};

export default Grid;