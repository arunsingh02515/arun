
import {AgGridColumn, AgGridReact} from 'ag-grid-react';
import React, { useState, useEffect,useRef } from 'react';
import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-alpine.css';
import { w3cwebsocket as W3CWebSocket } from "websocket";
import Grid from './Grid';
const client = new W3CWebSocket('ws://city-ws.herokuapp.com');


const App = () => {
   
   const [rowData, setRowData] = useState([]);
   let dataMap = useRef(null);
   useEffect(() => {
    client.onopen = () => {
      console.log('WebSocket Client Connected');
    };
    client.onmessage = (res) => {
      let arr=JSON.parse(res.data);
      let map = {};
      for(let i =0; i<arr.length;i++){
        let d= new Date();
        let minSecObj={};
        minSecObj.min = d.getMinutes();
        minSecObj.sec = d.getSeconds();
        map[arr[i].city] = minSecObj;
        
        let time = d.toLocaleTimeString({ hour12: false });
        if(dataMap.current != null) {
          arr[i].time= calculateTimeDiff(arr[i],dataMap,d);
        }
        else {
         arr[i].time = time;
         
        }
        arr[i].aqi= (Math.round(arr[i].aqi * 100) / 100).toFixed(2);
         
      }
      dataMap = map;
      dataMap.current="xyz";
      console.log("dataMap===="+ dataMap);
      setRowData(arr);
    };
    });

  let calculateTimeDiff = (obj,dataMap,date) => {
    let time= dataMap[obj.city];
    if(time != undefined) {
    if((date.getMinutes()-time.min)===1){
       return "A minute ago";  //Will get from constant file
    } 
    
    else if((date.getSeconds()-time.sec)>0){
       return "A few seconds ago";   //Will get from constant file
    } 
    else {
      return date.toLocaleTimeString({ hour12: false });
   }
    
  }
  else {
     return date.toLocaleTimeString({ hour12: false });
  }
  
  };



   return (
      <Grid rowData={rowData}></Grid>
       
   );
};

export default App;