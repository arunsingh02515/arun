module.exports.getColorCode = function (val) { 
    let aqi = Math.round(val);
    
    if(aqi>=0 && aqi<=50){
      return {color: '#339933'}; 
    }
    else if(aqi>=51 && aqi<=100){
      return {color: '#99cc00'}; 
    }
    else if(aqi>=101 && aqi<=200){
      return {color: '#ffff00'}; 
    }
    else if(aqi>=201 && aqi<=300){
      return {color: '#ff6600'}; 
    }
    else if(aqi>=301 && aqi<=400){
      return {color: '#ff531a'}; 
    }
    else if(aqi>=401 && aqi<=500){
      return {color: '#cc3300'}; 
    }
    
};


