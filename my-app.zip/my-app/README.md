How to run this project ? . Please use the below command.

1. npm install
2. npm start


I have used grid library to display data. It also provides filter, sorting ,search funcationality.

Design :
1. Created App component that fetch data from Websocket and send to Grid Component.
2. Created Grid component that recieve data from App component. It render data in Grid.
3. Created Util js  

 