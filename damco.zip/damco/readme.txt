1. Install mongodb and create database mydb. Mangodb running on port 27017
2. Created 2 project. user-service and user-gateway. Please do mvn clean install and run spring boot application
3. user-service running on localhost port 8080 and user-gateway on 8111.
4. Implemented zuul proxy so we can access application from zuul gateway.
5. Provided postman collection for all endpoints.Please import it in postman to execute the services.
6. Swagger- http://localhost:8080/swagger-ui.html


Below are implemented
1. Zuul Proxy
2. Swagger 
3. Unit Testing
4. API field validation
5. Global exception


